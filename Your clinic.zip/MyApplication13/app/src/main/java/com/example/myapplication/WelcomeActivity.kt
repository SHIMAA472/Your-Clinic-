package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase


class WelcomeActivity : AppCompatActivity() {
    lateinit var image456: ImageButton
    @SuppressLint("MissingInflatedId")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_welcome)
        image456 = findViewById(R.id.image456)


        val database = FirebaseDatabase.getInstance().getReference("Users")


        image456.setOnClickListener {
            val intent = Intent(this, DoctorActivity2::class.java)
            startActivity(intent)
        }

    }
}