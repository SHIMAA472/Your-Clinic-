package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class BookingActivity2 : AppCompatActivity() {
    lateinit var btnConfirm:Button
    lateinit var  btnCancel: Button
    lateinit var textView7: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_booking2)

        val btnConfirm = findViewById<Button>(R.id.btnConfirm)
        val btnCancel = findViewById<Button>(R.id.btnCancel)
        textView7 = findViewById(R.id.textView7)
        btnConfirm.setOnClickListener {
            Toast.makeText(this, "Your reservation has been confirmed successfully", Toast.LENGTH_SHORT).show()
        }

        btnCancel.setOnClickListener {
            Toast.makeText(this, "Your reservation has been cancelled", Toast.LENGTH_SHORT).show()
        }
        textView7.setOnClickListener {
            val intent = Intent(this, DoctorActivity2::class.java)
            startActivity(intent)
            finish()
        }
    }
}

