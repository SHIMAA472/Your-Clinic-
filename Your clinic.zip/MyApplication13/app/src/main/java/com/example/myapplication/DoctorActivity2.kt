package com.example.myapplication
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class DoctorActivity2 : AppCompatActivity() {

    lateinit var name: EditText
    lateinit var but1: Button
    lateinit var btnBack: ImageView
    lateinit var ViewDoctors: ImageView

    val doctorsList = arrayListOf(
        "Dr. Sarah Khalil",
        "Dr. Lila Sbah",
        "Dr. Ameen Hassan",
        "Dr. Ahmad Saeed"
    )

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctora2)

        name = findViewById(R.id.name)
        but1 = findViewById(R.id.but1)
        btnBack = findViewById(R.id.btnBack)
        ViewDoctors = findViewById(R.id.ViewDoctors)


        val database = FirebaseDatabase.getInstance().getReference("Users")

        ViewDoctors.setOnClickListener {
            val text = name.text.toString().trim()

            if (text.isEmpty()) {
                Toast.makeText(this, "اكتب اسم الدكتور", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val foundDoctor = doctorsList.find {
                it.contains(text, ignoreCase = true)
            }

            if (foundDoctor != null) {
                Toast.makeText(this, " اسم الدكتور المختار : $foundDoctor", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "لا يوجد دكتور بهذا الاسم", Toast.LENGTH_SHORT).show()
            }
        }



        but1.setOnClickListener {
            startActivity(Intent(this, BookingActivity2::class.java))
        }

        btnBack.setOnClickListener {
            startActivity(Intent(this, WelcomeActivity::class.java))
            finish()
        }
    }
}
