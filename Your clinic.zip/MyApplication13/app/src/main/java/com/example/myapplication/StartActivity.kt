package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase



class StartActivity : AppCompatActivity() {
    lateinit var Title:TextView
    lateinit var tvSubtitle:TextView
    lateinit var btnContinue:Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_start)
       Title =findViewById(R.id.Title)
        tvSubtitle= findViewById(R.id.tvSubtitle)
        btnContinue= findViewById(R.id.btnContinue)
        btnContinue.setOnClickListener {
            val Title = Title.text.toString()
            val  tvSubtitle= tvSubtitle.text.toString()
            val  btnContinue= btnContinue.text.toString()
            val database= FirebaseDatabase.getInstance().getReference ("Users")
            val user=User(Title , tvSubtitle , btnContinue)
            database.child(Title).setValue(user).addOnSuccessListener{
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }

        }
    }
