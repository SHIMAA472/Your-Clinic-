package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class LoginActivity : AppCompatActivity() {
    lateinit var editTextEmail: EditText
    lateinit var editTextPassword: EditText
    lateinit var buttonLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        editTextEmail = findViewById(R.id.editTextTextEmailAddress)
        editTextPassword = findViewById(R.id.editTextNumberPassword)
        buttonLogin = findViewById(R.id.button1)

        val database = FirebaseDatabase.getInstance().getReference("Users")

        buttonLogin.setOnClickListener {
            val email = editTextEmail.text.toString()
            val passwordInput = editTextPassword.text.toString()

            if (email.isEmpty() || passwordInput.isEmpty()) {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val emailKey = email.replace(".", ",")

            database.child(emailKey).get().addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    val passwordDB = snapshot.child("password").value
                    if (passwordInput == passwordDB.toString()) {
                        Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, WelcomeActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(this, "Password Incorrect", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "User Doesn't Exist", Toast.LENGTH_SHORT).show()
                }
            }.addOnFailureListener {
                Toast.makeText(this, "Failed to read database", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
