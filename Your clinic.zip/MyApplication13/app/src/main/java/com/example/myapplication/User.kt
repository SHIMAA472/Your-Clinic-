package com.example.myapplication

data class User( val Title:String,val tvSubtitle : String , val btnContinue: String )
